import re
import unicodedata

import torch

PAD, BOS, SEP, EOS, BYTE_OFFSET = 0, 1, 2, 3, 4
VOCAB_SIZE = 260


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).translate(
        str.maketrans({"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-", "…": "..."})
    )
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        raise ValueError("Empty transcript")
    return text


def tokenize(reference: str, target: str):
    ref = list(normalize(reference).encode("utf-8")) if reference.strip() else []
    tgt = list(normalize(target).encode("utf-8"))
    tokens = [BOS] + [v + BYTE_OFFSET for v in ref] + [SEP] + [v + BYTE_OFFSET for v in tgt] + [EOS]
    segments = [0] * (len(ref) + 2) + [1] * (len(tgt) + 1)
    return torch.tensor(tokens, dtype=torch.long), torch.tensor(segments, dtype=torch.long)
