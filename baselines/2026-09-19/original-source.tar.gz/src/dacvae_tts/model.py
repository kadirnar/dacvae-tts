"""Reference-conditioned, non-autoregressive continuous latent flow model."""

import math

import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.checkpoint import checkpoint

from .config import ModelConfig
from .text import BYTE_OFFSET, VOCAB_SIZE


def sinusoidal(positions, width):
    freq = torch.exp(
        torch.arange(width // 2, device=positions.device).float()
        * (-math.log(10000) / max(width // 2 - 1, 1))
    )
    angles = positions.float().unsqueeze(-1) * freq
    return torch.cat([angles.sin(), angles.cos()], dim=-1)


def masked_mean(x, mask):
    return (x * mask[..., None]).sum(1) / mask.sum(1, keepdim=True).clamp_min(1)


class Attention(nn.Module):
    def __init__(self, width, heads):
        super().__init__()
        self.heads = heads
        self.q = nn.Linear(width, width)
        self.kv = nn.Linear(width, width * 2)
        self.out = nn.Linear(width, width)

    def forward(self, x, context, valid):
        b, n, d = x.shape
        q = self.q(x).view(b, n, self.heads, d // self.heads).transpose(1, 2)
        k, v = self.kv(context).chunk(2, dim=-1)
        k = k.view(b, -1, self.heads, d // self.heads).transpose(1, 2)
        v = v.view(b, -1, self.heads, d // self.heads).transpose(1, 2)
        y = F.scaled_dot_product_attention(q, k, v, attn_mask=valid[:, None, None, :])
        return self.out(y.transpose(1, 2).reshape(b, n, d))


class TextEncoder(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        d = cfg.width
        self.embedding = nn.Embedding(VOCAB_SIZE, d, padding_idx=0)
        self.segment = nn.Embedding(2, d)
        self.convs = nn.ModuleList([nn.Conv1d(d, d, 7, padding=3, groups=d) for _ in range(cfg.text_depth)])
        self.mlps = nn.ModuleList(
            [
                nn.Sequential(nn.LayerNorm(d), nn.Linear(d, 2 * d), nn.GELU(), nn.Linear(2 * d, d))
                for _ in range(cfg.text_depth)
            ]
        )
        self.norm = nn.LayerNorm(d)

    def forward(self, tokens, segments):
        valid = tokens.ne(0)
        x = self.embedding(tokens) + self.segment(segments)
        x = x + sinusoidal(torch.arange(tokens.size(1), device=x.device), x.size(-1)).to(x.dtype)
        for conv, mlp in zip(self.convs, self.mlps):
            x = x * valid[..., None]
            x = x + mlp(conv(x.transpose(1, 2)).transpose(1, 2))
        return self.norm(x) * valid[..., None], valid


class Block(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        d = cfg.width
        self.norm1 = nn.LayerNorm(d, elementwise_affine=False)
        self.norm2 = nn.LayerNorm(d, elementwise_affine=False)
        self.norm3 = nn.LayerNorm(d, elementwise_affine=False)
        self.self_attn = Attention(d, cfg.heads)
        self.cross_attn = Attention(d, cfg.heads)
        self.ff = nn.Sequential(
            nn.Linear(d, d * cfg.ff_mult), nn.GELU(approximate="tanh"), nn.Linear(d * cfg.ff_mult, d)
        )
        self.ada = nn.Sequential(nn.SiLU(), nn.Linear(d, d * 9))
        nn.init.zeros_(self.ada[-1].weight)
        nn.init.zeros_(self.ada[-1].bias)

    def forward(self, x, text, valid, text_valid, cond):
        params = self.ada(cond).unsqueeze(1).chunk(9, dim=-1)
        s1, b1, g1, s2, b2, g2, s3, b3, g3 = params
        h = self.norm1(x) * (1 + s1) + b1
        x = x + g1 * self.self_attn(h, h, valid)
        h = self.norm2(x) * (1 + s2) + b2
        x = x + g2 * self.cross_attn(h, text, text_valid)
        x = x + g3 * self.ff(self.norm3(x) * (1 + s3) + b3)
        return x * valid[..., None]


class FlowTTS(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        self.cfg = cfg
        d, c, p = cfg.width, cfg.latent_dim, cfg.patch_size
        self.text = TextEncoder(cfg)
        self.ref = nn.Sequential(nn.Linear(c, d), nn.SiLU(), nn.Linear(d, d))
        self.time = nn.Sequential(nn.Linear(d, d), nn.SiLU(), nn.Linear(d, d))
        self.input = nn.Linear((2 * c + 1) * p, d)
        self.blocks = nn.ModuleList([Block(cfg) for _ in range(cfg.depth)])
        self.output = nn.Sequential(nn.LayerNorm(d), nn.Linear(d, c * p))
        nn.init.zeros_(self.output[-1].weight)
        nn.init.zeros_(self.output[-1].bias)
        self.duration = nn.Sequential(nn.Linear(2 * d + 1, d), nn.SiLU(), nn.Linear(d, 1))
        self.grad_checkpoint = False

    def conditions(self, prompt, prompt_mask, tokens, segments, drop=None):
        text, text_valid = self.text(tokens, segments)
        voice = masked_mean(self.ref(prompt), prompt_mask)
        if drop is not None:
            text = text * (~drop)[:, None, None]
            voice = voice * (~drop)[:, None]
        return text, text_valid, voice

    def predict_duration(self, prompt, prompt_mask, tokens, segments):
        text, _, voice = self.conditions(prompt, prompt_mask, tokens, segments)
        target_bytes = (segments == 1) & (tokens >= BYTE_OFFSET)
        ref_bytes = ((segments == 0) & (tokens >= BYTE_OFFSET)).sum(1).clamp_min(1)
        rate = (prompt_mask.sum(1).float().clamp_min(1) / ref_bytes).log().unsqueeze(1)
        return self.duration(torch.cat([masked_mean(text, target_bytes), voice, rate], -1)).squeeze(-1)

    def forward(self, x, time, prompt, prompt_mask, valid, tokens, segments, drop=None, cached=None):
        b, length, channels = x.shape
        p = self.cfg.patch_size
        if cached is None:
            cached = self.conditions(prompt, prompt_mask, tokens, segments, drop)
        text, text_valid, voice = cached
        if drop is not None:
            prompt = prompt * (~drop)[:, None, None]
            prompt_mask = prompt_mask & (~drop)[:, None]
        features = torch.cat([x, prompt, prompt_mask[..., None].to(x.dtype)], -1)
        pad = (-length) % p
        features = F.pad(features, (0, 0, 0, pad))
        packed_valid = F.pad(valid, (0, pad)).reshape(b, -1, p).any(-1)
        h = self.input(features.reshape(b, -1, features.size(-1) * p))
        h = h + sinusoidal(torch.arange(h.size(1), device=x.device), h.size(-1)).to(h.dtype)
        cond = self.time(sinusoidal(time * 1000, self.cfg.width).to(h.dtype)) + voice
        for block in self.blocks:
            args = (h, text, packed_valid, text_valid, cond)
            h = (
                checkpoint(block, *args, use_reentrant=False)
                if self.grad_checkpoint and self.training
                else block(*args)
            )
        return self.output(h).reshape(b, -1, channels)[:, :length] * valid[..., None]


def per_example_mse(prediction, target, mask):
    error = (prediction.float() - target.float()).square().mean(-1)
    return (error * mask).sum(-1) / mask.sum(-1).clamp_min(1)


def flow_loss(model, batch, dropout=0.1, time=None, noise=None):
    x1 = batch["latents"]
    b = x1.size(0)
    time = torch.rand(b, device=x1.device) if time is None else time
    noise = torch.randn_like(x1) if noise is None else noise
    mask = batch["valid"] & ~batch["prompt_mask"]
    xt = (1 - time[:, None, None]) * noise + time[:, None, None] * x1
    # The conditioning prefix follows exactly the same path at training and inference.
    xt = torch.where(batch["prompt_mask"][..., None], x1, xt) * batch["valid"][..., None]
    drop = torch.rand(b, device=x1.device) < dropout
    # Remove reference from the state too, otherwise CFG's null branch leaks the voice.
    xt = xt.masked_fill((drop[:, None] & batch["prompt_mask"])[..., None], 0)
    pred = model(
        xt,
        time,
        batch["prompt"],
        batch["prompt_mask"],
        batch["valid"],
        batch["tokens"],
        batch["segments"],
        drop=drop,
    )
    return per_example_mse(pred, x1 - noise, mask)


@torch.inference_mode()
def sample(
    model,
    prompt,
    prompt_mask,
    valid,
    tokens,
    segments,
    steps=16,
    guidance=1.5,
    seed=0,
    sway=-1.0,
    return_trajectory=False,
):
    if steps < 1 or not -1 <= sway <= 0 or not math.isfinite(guidance) or guidance < 0:
        raise ValueError("Invalid sampler settings")
    gen = torch.Generator(device=prompt.device).manual_seed(seed)
    x = torch.randn(prompt.shape, device=prompt.device, dtype=prompt.dtype, generator=gen)
    x = torch.where(prompt_mask[..., None], prompt, x) * valid[..., None]
    times = torch.linspace(0, 1, steps + 1, device=x.device)
    times = times + sway * (torch.cos(times * math.pi / 2) - 1 + times)
    cond = model.conditions(prompt, prompt_mask, tokens, segments)
    null = (
        model.conditions(
            torch.zeros_like(prompt),
            torch.zeros_like(prompt_mask),
            tokens,
            segments,
            torch.ones(x.size(0), device=x.device, dtype=torch.bool),
        )
        if guidance != 1
        else None
    )
    trajectory = [x.clone()] if return_trajectory else None
    for t0, t1 in zip(times[:-1], times[1:]):
        t = t0.expand(x.size(0))
        v = model(x, t, prompt, prompt_mask, valid, tokens, segments, cached=cond)
        if guidance != 1:
            null_x = x.masked_fill(prompt_mask[..., None], 0)
            u = model(
                null_x,
                t,
                torch.zeros_like(prompt),
                torch.zeros_like(prompt_mask),
                valid,
                tokens,
                segments,
                cached=null,
            )
            v = u + guidance * (v - u)
        x = x + (t1 - t0) * v
        x = torch.where(prompt_mask[..., None], prompt, x) * valid[..., None]
        if trajectory is not None:
            trajectory.append(x.clone())
    return (x, times, torch.stack(trajectory)) if return_trajectory else x
