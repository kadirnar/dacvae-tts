import math

import numpy as np
import soundfile as sf
import torch
from scipy.signal import resample_poly


def read_audio(path, sample_rate):
    audio, sr = sf.read(path, dtype="float32", always_2d=True)
    audio = audio.mean(axis=1)
    if not len(audio) or not np.isfinite(audio).all():
        raise ValueError(f"Empty or nonfinite audio: {path}")
    if sr != sample_rate:
        factor = math.gcd(sr, sample_rate)
        audio = resample_poly(audio, sample_rate // factor, sr // factor).astype(np.float32)
    return torch.from_numpy(audio.copy())


class Codec:
    """Frozen DACVAE; model-specific details are discovered, never guessed."""

    def __init__(self, checkpoint="facebook/dacvae-watermarked", device="cpu"):
        from dacvae import DACVAE

        self.device = torch.device(device)
        self.model = DACVAE.load(checkpoint).to(self.device).eval().requires_grad_(False)
        self.sample_rate = int(self.model.sample_rate)
        self.hop_length = int(self.model.hop_length)
        # Probe the posterior, not DAC's pre-bottleneck latent_dim attribute.
        with torch.inference_mode():
            z = self.encode(torch.zeros(self.sample_rate, device=self.device))
        self.latent_dim = z.size(-1)
        self.checkpoint = checkpoint

    @property
    def metadata(self):
        return {
            "checkpoint": self.checkpoint,
            "sample_rate": self.sample_rate,
            "hop_length": self.hop_length,
            "latent_dim": self.latent_dim,
            "posterior": "mean",
            "format_version": 1,
        }

    @torch.inference_mode()
    def encode(self, audio):
        audio = audio.to(self.device).reshape(1, 1, -1)
        if audio.size(-1) < self.hop_length * 2:
            raise ValueError("Audio too short for DACVAE")
        z = self.model.encoder(self.model._pad(audio))
        mean, _ = self.model.quantizer.in_proj(z).chunk(2, dim=1)
        return mean[0].transpose(0, 1).contiguous().float()

    @torch.inference_mode()
    def decode(self, latents):
        waveform = self.model.decode(latents.to(self.device).T[None].contiguous())
        return waveform[0, 0].float().cpu()
