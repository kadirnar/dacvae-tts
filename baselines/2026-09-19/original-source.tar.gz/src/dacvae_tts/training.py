"""DDP training with sample-weighted accumulation and per-rank resumable RNG state."""

import copy
import json
import math
import os
import random
import time
from contextlib import nullcontext
from pathlib import Path

import torch
import torch.distributed as dist
from torch import nn
from torch.nn import functional as F
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader

from .config import Config
from .data import BucketBatchSampler, LatentDataset, collate, move_batch
from .model import FlowTTS, flow_loss
from .text import BYTE_OFFSET


class Objective(nn.Module):
    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, batch):
        flow = flow_loss(self.model, batch, self.model.cfg.cond_dropout if self.training else 0)
        frames = (batch["valid"] & ~batch["prompt_mask"]).sum(1)
        characters = ((batch["segments"] == 1) & (batch["tokens"] >= BYTE_OFFSET)).sum(1)
        log_rate = (frames / characters.clamp_min(1)).log()
        duration = self.model.predict_duration(
            batch["prompt"], batch["prompt_mask"], batch["tokens"], batch["segments"]
        )
        duration_loss = F.smooth_l1_loss(duration.float(), log_rate, reduction="none")
        return {"loss": flow + 0.1 * duration_loss, "flow": flow, "duration": duration_loss}


def distributed_device(requested="auto"):
    world = int(os.environ.get("WORLD_SIZE", 1))
    rank, local = int(os.environ.get("RANK", 0)), int(os.environ.get("LOCAL_RANK", 0))
    use_cuda = torch.cuda.is_available() and requested != "cpu"
    device = torch.device(f"cuda:{local}" if use_cuda else "cpu")
    if use_cuda:
        torch.cuda.set_device(device)
        torch.set_float32_matmul_precision("high")
    if world > 1:
        dist.init_process_group("nccl" if use_cuda else "gloo")
    return device, rank, world


def autocast(device, precision):
    return torch.autocast(device.type, dtype=torch.bfloat16, enabled=precision == "bf16")


def atomic_save(obj, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(obj, temporary)
    os.replace(temporary, path)


def load_model(path, device="cpu", ema=True):
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    cfg = Config.from_dict(checkpoint["config"])
    model = FlowTTS(cfg.model)
    model.load_state_dict(checkpoint["ema"] if ema else checkpoint["model"])
    return model.to(device).eval(), checkpoint


def lr_multiplier(step, warmup, steps):
    if step < warmup:
        return (step + 1) / max(warmup, 1)
    progress = (step - warmup) / max(steps - warmup, 1)
    return 0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * min(progress, 1)))


def rng_state(device):
    return {
        "torch": torch.get_rng_state(),
        "python": random.getstate(),
        "cuda": torch.cuda.get_rng_state(device) if device.type == "cuda" else None,
    }


def restore_rng(state, device):
    torch.set_rng_state(state["torch"])
    random.setstate(state["python"])
    if state["cuda"] is not None and device.type == "cuda":
        torch.cuda.set_rng_state(state["cuda"], device)


def validate(model, loader, device, precision, max_batches=20):
    objective = Objective(model).eval()
    totals = torch.zeros(2, device=device)
    devices = [device.index] if device.type == "cuda" else []
    with torch.no_grad(), torch.random.fork_rng(devices=devices):
        torch.manual_seed(12345)
        for i, batch in enumerate(loader):
            if i >= max_batches:
                break
            with autocast(device, precision):
                losses = objective(move_batch(batch, device))["loss"]
            totals[0] += losses.sum()
            totals[1] += losses.numel()
    if dist.is_initialized():
        dist.all_reduce(totals)
    return (totals[0] / totals[1].clamp_min(1)).item()


def train(args):
    device, rank, world = distributed_device(args.device)
    try:
        if (Path(args.output) / "last.pt").exists() and not args.resume:
            raise ValueError("Output already has a checkpoint; pass --resume or choose a new run directory")
        cfg = Config.load(args.config)
        for key in ("steps", "batch_size", "accumulation", "workers", "precision", "learning_rate"):
            value = getattr(args, key, None)
            if value is not None:
                setattr(cfg.train, key, value)
        if args.compile:
            cfg.train.compile = True
        cfg.train.__post_init__()
        if device.type == "cuda" and cfg.train.precision == "bf16" and not torch.cuda.is_bf16_supported():
            raise ValueError("This GPU does not support BF16; pass --precision fp32")
        torch.manual_seed(cfg.train.seed)
        random.seed(cfg.train.seed)
        data = LatentDataset(args.cache, "train", cfg.train.seed)
        if not data.meta.get("merged"):
            raise ValueError("Run merge on all prepared partitions before training")
        if cfg.model.latent_dim != data.channels:
            raise ValueError(f"Config latent_dim={cfg.model.latent_dim}, codec cache has {data.channels}")
        sampler = BucketBatchSampler(
            data.costs, cfg.train.batch_size, rank, world, cfg.train.seed, args.frame_budget
        )
        loader_rng = torch.Generator().manual_seed(cfg.train.seed + rank)
        loader = DataLoader(
            data,
            batch_sampler=sampler,
            collate_fn=collate,
            num_workers=cfg.train.workers,
            pin_memory=device.type == "cuda",
            persistent_workers=cfg.train.workers > 0,
            generator=loader_rng,
        )
        validation = None
        if not args.no_validation:
            val_data = LatentDataset(args.cache, "val", cfg.train.seed)
            val_sampler = BucketBatchSampler(val_data.costs, cfg.train.batch_size, rank, world, 12345)
            validation = DataLoader(
                val_data,
                batch_sampler=val_sampler,
                collate_fn=collate,
                num_workers=0,
                generator=torch.Generator().manual_seed(0),
            )
        model = FlowTTS(cfg.model).to(device)
        model.grad_checkpoint = cfg.train.grad_checkpoint
        ema = copy.deepcopy(model).eval().requires_grad_(False)
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=cfg.train.learning_rate,
            weight_decay=cfg.train.weight_decay,
            betas=(0.9, 0.95),
            fused=device.type == "cuda",
        )
        start_step, epoch, batch_offset = 0, 0, 0
        if args.resume:
            saved = torch.load(args.resume, map_location="cpu", weights_only=True)
            if saved["config"] != cfg.to_dict():
                raise ValueError(
                    "Resume requires the original configuration; use finetuning for changed schedules"
                )
            if saved["world_size"] != world:
                raise ValueError("Exact resume requires the same GPU count")
            if (
                saved["cache_path"] != str(Path(args.cache).resolve())
                or saved["frame_budget"] != args.frame_budget
            ):
                raise ValueError("Resume requires the same cache path and frame budget")
            model.load_state_dict(saved["model"])
            ema.load_state_dict(saved["ema"])
            optimizer.load_state_dict(saved["optimizer"])
            start_step, epoch, batch_offset = saved["step"], saved["epoch"], saved["batch_offset"]
            restore_rng(saved["rng"][rank], device)
        else:
            torch.manual_seed(cfg.train.seed + rank)
            random.seed(cfg.train.seed + rank)
        objective = Objective(model).train()
        if cfg.train.compile:
            objective = torch.compile(objective, dynamic=True)
        if world > 1:
            objective = DDP(
                objective,
                device_ids=[device.index] if device.type == "cuda" else None,
                broadcast_buffers=False,
                gradient_as_bucket_view=True,
            )
        out = Path(args.output)
        if rank == 0:
            out.mkdir(parents=True, exist_ok=True)
            (out / "config.json").write_text(json.dumps(cfg.to_dict(), indent=2))
            print(
                json.dumps(
                    {
                        "parameters": sum(p.numel() for p in model.parameters()),
                        "ranks": world,
                        "maximum_global_batch": cfg.train.batch_size * cfg.train.accumulation * world,
                        "train_rows": len(data),
                    }
                ),
                flush=True,
            )
        sampler.epoch, sampler.start_batch = epoch, batch_offset
        iterator = iter(loader)
        last_time = time.monotonic()
        for step in range(start_step, cfg.train.steps):
            # Collect a window before backward so variable batches receive exact example weighting.
            batches = []
            for _ in range(cfg.train.accumulation):
                try:
                    batch = next(iterator)
                except StopIteration:
                    epoch += 1
                    batch_offset = 0
                    sampler.epoch, sampler.start_batch = epoch, 0
                    iterator = iter(loader)
                    batch = next(iterator)
                batch_offset += 1
                batches.append(batch)
            denominator = torch.tensor(sum(b["latents"].size(0) for b in batches), device=device)
            if world > 1:
                dist.all_reduce(denominator)
            learning_rate = cfg.train.learning_rate * lr_multiplier(step, cfg.train.warmup, cfg.train.steps)
            for group in optimizer.param_groups:
                group["lr"] = learning_rate
            optimizer.zero_grad(set_to_none=True)
            metrics = torch.zeros(3, device=device)
            for micro, batch in enumerate(batches):
                batch = move_batch(batch, device)
                sync = objective.no_sync() if world > 1 and micro < len(batches) - 1 else nullcontext()
                with sync:
                    with autocast(device, cfg.train.precision):
                        losses = objective(batch)
                        loss = losses["loss"].sum() * world / denominator
                    loss.backward()
                metrics += torch.stack(
                    [
                        losses["loss"].detach().sum(),
                        losses["flow"].detach().sum(),
                        losses["duration"].detach().sum(),
                    ]
                )
            norm = nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            if not torch.isfinite(norm):
                raise FloatingPointError(f"Nonfinite gradient at update {step + 1}")
            optimizer.step()
            with torch.no_grad():
                torch._foreach_lerp_(
                    list(ema.parameters()), list(model.parameters()), 1 - cfg.train.ema_decay
                )
            if (step + 1) % cfg.train.log_every == 0 or step == start_step:
                if world > 1:
                    dist.all_reduce(metrics)
                if rank == 0:
                    record = {
                        "step": step + 1,
                        "epoch": epoch,
                        "lr": learning_rate,
                        "loss": (metrics[0] / denominator).item(),
                        "flow": (metrics[1] / denominator).item(),
                        "duration": (metrics[2] / denominator).item(),
                        "elapsed_seconds": time.monotonic() - last_time,
                    }
                    print(json.dumps(record), flush=True)
                    with open(out / "train.jsonl", "a") as stream:
                        stream.write(json.dumps(record) + "\n")
                last_time = time.monotonic()
            if validation is not None and (step + 1) % cfg.train.validate_every == 0:
                val_loss = validate(ema, validation, device, cfg.train.precision)
                if rank == 0:
                    print(json.dumps({"step": step + 1, "validation_loss": val_loss}), flush=True)
            stopping = args.stop_after is not None and step + 1 >= args.stop_after
            if (step + 1) % cfg.train.checkpoint_every == 0 or step + 1 == cfg.train.steps or stopping:
                states = [None] * world
                state = rng_state(device)
                if world > 1:
                    dist.all_gather_object(states, state)
                else:
                    states[0] = state
                if rank == 0:
                    saved = {
                        "model": model.state_dict(),
                        "ema": ema.state_dict(),
                        "optimizer": optimizer.state_dict(),
                        "config": cfg.to_dict(),
                        "step": step + 1,
                        "epoch": epoch,
                        "batch_offset": batch_offset,
                        "rng": states,
                        "world_size": world,
                        "frame_budget": args.frame_budget,
                        "cache_path": str(Path(args.cache).resolve()),
                        "codec": data.meta,
                        "mean": data.mean,
                        "std": data.std,
                        "stage": "pretrain",
                    }
                    atomic_save(saved, out / "last.pt")
                if world > 1:
                    dist.barrier()
            if stopping:
                break
    finally:
        if dist.is_initialized():
            dist.destroy_process_group()
