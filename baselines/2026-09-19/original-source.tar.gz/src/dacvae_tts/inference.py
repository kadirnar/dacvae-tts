import json
import math
import time
from pathlib import Path

import soundfile as sf
import torch

from .codec import Codec, read_audio
from .model import sample
from .text import BYTE_OFFSET, tokenize
from .training import autocast, load_model


class Synthesizer:
    def __init__(self, checkpoint, device="cuda", precision="bf16", compile_model=False):
        self.device = torch.device(device)
        self.precision = precision
        self.model, self.checkpoint = load_model(checkpoint, device)
        self.codec = Codec(self.checkpoint["codec"]["checkpoint"], device)
        for key in ("latent_dim", "sample_rate", "hop_length", "posterior"):
            if self.codec.metadata[key] != self.checkpoint["codec"][key]:
                raise ValueError(f"Checkpoint/codec mismatch: {key}")
        self.mean = self.checkpoint["mean"].to(device)
        self.std = self.checkpoint["std"].to(device)
        if compile_model:
            self.model.forward = torch.compile(self.model.forward, dynamic=True)

    def reference(self, path):
        audio = read_audio(path, self.codec.sample_rate)
        seconds = len(audio) / self.codec.sample_rate
        if not 0.5 <= seconds <= 30:
            raise ValueError("Reference must be a complete .5–30 second utterance with an exact transcript")
        return (self.codec.encode(audio) - self.mean) / self.std

    @torch.inference_mode()
    def make_batch(self, reference, reference_text, text, seconds=None, duration_scale=1.0):
        if not math.isfinite(duration_scale) or duration_scale <= 0:
            raise ValueError("duration_scale must be finite and positive")
        reference = reference.to(self.device)
        tokens, segments = tokenize(reference_text, text)
        tokens, segments = tokens[None].to(self.device), segments[None].to(self.device)
        if tokens.numel() > 2048:
            raise ValueError("Text too long; split into sentences before synthesis")
        if seconds is None:
            prompt = reference[None]
            mask = torch.ones(prompt.shape[:2], device=self.device, dtype=torch.bool)
            with autocast(self.device, self.precision):
                log_rate = self.model.predict_duration(prompt, mask, tokens, segments)
            nbytes = ((segments == 1) & (tokens >= BYTE_OFFSET)).sum().item()
            frames = round(math.exp(float(log_rate.clamp(-4, 6))) * nbytes * duration_scale)
        else:
            if not math.isfinite(seconds) or seconds <= 0:
                raise ValueError("seconds must be finite and positive")
            frames = round(seconds * self.codec.sample_rate / self.codec.hop_length * duration_scale)
        seconds = frames * self.codec.hop_length / self.codec.sample_rate
        if not 0.25 <= seconds <= 30:
            raise ValueError(
                f"Predicted/requested target duration {seconds:.2f}s is outside .25–30s; set --seconds"
            )
        prompt = torch.zeros(1, len(reference) + frames, self.codec.latent_dim, device=self.device)
        prompt[:, : len(reference)] = reference
        prompt_mask = torch.arange(prompt.size(1), device=self.device)[None] < len(reference)
        return {
            "prompt": prompt,
            "prompt_mask": prompt_mask,
            "valid": torch.ones_like(prompt_mask),
            "tokens": tokens,
            "segments": segments,
        }

    @torch.inference_mode()
    def generate(self, batch, steps=16, guidance=1.5, seed=0, sway=-1):
        if self.device.type == "cuda":
            torch.cuda.synchronize(self.device)
            torch.cuda.reset_peak_memory_stats(self.device)
        started = time.perf_counter()
        with autocast(self.device, self.precision):
            result = sample(self.model, **batch, steps=steps, guidance=guidance, seed=seed, sway=sway)
        target = result[0, ~batch["prompt_mask"][0]]
        # Decode target alone: no reference audio leaks into the output waveform.
        audio = self.codec.decode(target * self.std + self.mean)
        if self.device.type == "cuda":
            torch.cuda.synchronize(self.device)
        elapsed = time.perf_counter() - started
        duration = audio.numel() / self.codec.sample_rate
        return (
            audio,
            target.cpu(),
            {
                "generation_seconds": elapsed,
                "audio_seconds": duration,
                "rtf": elapsed / max(duration, 1e-6),
                "peak_cuda_bytes": torch.cuda.max_memory_allocated(self.device)
                if self.device.type == "cuda"
                else 0,
                "steps": steps,
                "guidance": guidance,
                "seed": seed,
            },
        )


def infer(args):
    tts = Synthesizer(args.checkpoint, args.device, args.precision, args.compile)
    reference = tts.reference(args.reference)
    batch = tts.make_batch(reference, args.reference_text, args.text, args.seconds, args.duration_scale)
    audio, _, metrics = tts.generate(batch, args.steps, args.guidance, args.seed, args.sway)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    sf.write(output, audio.numpy(), tts.codec.sample_rate, subtype="FLOAT")
    output.with_suffix(".json").write_text(json.dumps(metrics, indent=2))
    print(json.dumps(metrics, indent=2))
